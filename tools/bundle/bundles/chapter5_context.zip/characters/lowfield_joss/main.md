## Joss Lowfield – The Outgoing Workhorse

### 1. Core Identity
- **Role**: Lowfield elder son; His fathers son; handles heavy outdoor tasks.
- **Age & Background**: Mid-20s; strong, broad-shouldered.

### 2. Speech Style
- **Formality**: Casual, rural; blunt when urgency is high.
- **Cadence**: Short bursts; prefers action over talk.
- **Word Choice**: Workmanlike; adds light humor when possible.
- **Avoids**: Elaborate explanations.

### 3. Behavior & Mannerisms
- **Posture & Movement**: Carries weight with ease; plants feet firmly before lifting.
- **Stress Tells**: Tightens grip on load.
- **Comfort Zones**: Physical work, hauling.
- **Small Quirk**: Whistles tunelessly when hauling.

### 4. Interpersonal Patterns
- **Disagreement**: Quick to defer to Meed, but may grumble under breath.
- **Deference**: To Meed in the field.
- **Trust Signals**: Offers to carry more than his share.

### 5. Emotional Leakage
- **Anger**: Short, sharp remarks.
- **Fear**: Breath quickens; focuses harder on physical action.
- **Grief**: Keeps hands busy.
- **Relief/Small Joy**: Low chuckle after the work is done.
